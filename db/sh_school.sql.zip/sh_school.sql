-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Июн 02 2025 г., 21:15
-- Версия сервера: 8.0.34-26-beget-1-1
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `z91273sk_furn`
--

-- --------------------------------------------------------

--
-- Структура таблицы `sh_school`
--
-- Создание: Мар 25 2025 г., 23:30
--

DROP TABLE IF EXISTS `sh_school`;
CREATE TABLE `sh_school` (
  `id` int NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `sh_school`
--

INSERT INTO `sh_school` (`id`, `name`) VALUES
(1, 'МБОУ Гимназия №1'),
(2, 'МБОУ ООШ №4'),
(5, 'МБОУ ООШ №5'),
(6, 'МБОУ ООШ №7'),
(7, 'МБОУ ООШ №8'),
(8, 'МБОУ ООШ №9'),
(9, 'МБОУ ООШ №10'),
(10, 'МБОУ ООШ №11'),
(11, 'МБОУ ООШ №12'),
(12, 'МБОУ СОШ №14'),
(13, 'МБОУ СОШ №16'),
(14, 'МБОУ СОШ №19'),
(15, 'МБОУ СОШ №21'),
(16, 'МБОУ СОШ №23'),
(17, 'МБОУ СОШ №24'),
(18, 'МБОУ СОШ №28'),
(19, 'МБОУ СОШ №30'),
(20, 'МБОУ СОШ №32'),
(21, 'МБОУ СОШ №37'),
(22, 'МБОУ СОШ №76'),
(23, 'МБОУ Лицей №22'),
(24, 'ГПОУ «КМТ»'),
(25, 'ГПОУ «БЛПТ»'),
(26, 'ФГБОУ ВО «КемГУ»'),
(27, 'ГПОУ«БПК»'),
(28, 'ГПОУ «КМК» БФ'),
(29, 'ФГБОУ ВО «КузГТУ»');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `sh_school`
--
ALTER TABLE `sh_school`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `sh_school`
--
ALTER TABLE `sh_school`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
