-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Июн 02 2025 г., 21:15
-- Версия сервера: 8.0.34-26-beget-1-1
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `z91273sk_furn`
--

-- --------------------------------------------------------

--
-- Структура таблицы `sh_party`
--
-- Создание: Мар 25 2025 г., 23:30
--

DROP TABLE IF EXISTS `sh_party`;
CREATE TABLE `sh_party` (
  `id` int NOT NULL,
  `datetime_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `master` int NOT NULL,
  `pass` text NOT NULL,
  `datetime_change` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) DEFAULT NULL,
  `status` text,
  `contragent` int DEFAULT NULL,
  `winner` text,
  `red` int DEFAULT NULL,
  `black` int DEFAULT NULL,
  `red_time_left` int DEFAULT NULL,
  `black_time_left` int DEFAULT NULL,
  `red_time_last` datetime DEFAULT NULL,
  `black_time_last` datetime DEFAULT NULL,
  `current` text,
  `data` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `sh_party`
--

INSERT INTO `sh_party` (`id`, `datetime_create`, `master`, `pass`, `active`, `status`, `contragent`, `winner`, `red`, `black`, `red_time_left`, `black_time_left`, `red_time_last`, `black_time_last`, `current`, `data`) VALUES
(208, '2025-04-22 04:15:23', 864, 'MLOyLoBZ', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(209, '2025-04-22 04:15:23', 864, 'NMREgvfg', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(210, '2025-04-22 04:59:53', 869, 'xp5RgDaN', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(211, '2025-04-22 05:00:00', 870, 'o0MVQVoQ', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(212, '2025-04-22 05:00:12', 871, 'JchBx5TU', 1, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(213, '2025-04-22 05:00:16', 877, 'HBklRflH', 1, 'process', 874, NULL, 874, 877, NULL, NULL, NULL, NULL, 'red', NULL),
(214, '2025-04-22 05:00:16', 872, 'XWzQZI2O', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(215, '2025-04-22 05:00:24', 875, 'IBAzILLw', 0, 'end', 878, '878', 878, 875, NULL, NULL, NULL, NULL, 'black', NULL),
(216, '2025-04-22 05:00:30', 869, '4gUxlkFt', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(217, '2025-04-22 05:00:54', 879, 'JfEW7PXj', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(218, '2025-04-22 05:01:11', 869, 'o9Ujo2iq', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(219, '2025-04-22 05:01:13', 870, 'cj1HID0R', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(220, '2025-04-22 05:01:18', 873, 'FG44s55V', 1, 'process', 881, NULL, 881, 873, NULL, NULL, NULL, NULL, 'red', NULL),
(221, '2025-04-22 05:01:24', 880, 'zhNE1rsd', 1, 'process', 869, NULL, 869, 880, NULL, NULL, NULL, NULL, 'red', NULL),
(222, '2025-04-22 05:01:52', 872, 'A9CWTzpa', 1, 'process', 882, NULL, 872, 882, NULL, NULL, NULL, NULL, 'black', NULL),
(223, '2025-04-22 05:01:57', 870, 'T9MMVy0X', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(224, '2025-04-22 05:02:02', 879, 'rDzVB9nL', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(225, '2025-04-22 05:02:57', 876, 'o49ebEuf', 0, 'end', 885, '885', 885, 876, NULL, NULL, NULL, NULL, 'black', NULL),
(226, '2025-04-22 05:03:09', 870, 'AzRVNHG8', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(227, '2025-04-22 05:03:24', 870, 'lZIGPlsa', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(228, '2025-04-22 05:03:36', 879, '3l02OjsQ', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(229, '2025-04-22 05:04:54', 870, 'eDnAe4u4', 1, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(230, '2025-04-22 05:09:08', 886, '95rooJf5', 1, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(231, '2025-04-22 05:11:51', 876, 'R5vX7BX5', 1, 'process', 885, NULL, 876, 885, NULL, NULL, NULL, NULL, 'black', NULL),
(232, '2025-04-22 05:26:25', 778, 'F5YCkOPb', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(233, '2025-04-22 05:26:49', 778, 'bsXIWW7x', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(234, '2025-04-22 05:27:02', 778, '2eqxn3DZ', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(235, '2025-04-22 05:28:41', 887, 'l1vyBhDJ', 0, 'end', 778, '887', 778, 887, NULL, NULL, NULL, NULL, 'red', NULL),
(236, '2025-04-22 06:01:09', 894, 'pslRNuex', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(237, '2025-04-22 06:01:29', 896, 'WMttgVLm', 1, 'process', 891, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(238, '2025-04-22 06:01:54', 894, 'fQeF6MKQ', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(239, '2025-04-22 06:02:22', 894, 'rRFvdnEC', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(240, '2025-04-22 06:02:26', 893, 'c8t26RD8', 1, 'process', 889, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(241, '2025-04-22 06:02:31', 894, '0l3YKHHJ', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(242, '2025-04-22 06:02:41', 894, 'vEiz7W9h', 1, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(243, '2025-04-22 06:05:05', 902, 'OKiBtspJ', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(244, '2025-04-22 06:06:12', 901, 'UJRJ3OgV', 1, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(245, '2025-04-22 06:08:10', 902, 'DEq3w7re', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(246, '2025-04-22 06:28:44', 903, 'EVAycdfL', 1, 'process', 904, NULL, 903, 904, NULL, NULL, NULL, NULL, 'black', NULL),
(247, '2025-04-22 06:51:30', 907, 'YD50mC9J', 1, 'process', 908, NULL, 908, 907, NULL, NULL, NULL, NULL, 'black', NULL),
(248, '2025-04-22 10:13:39', 912, 'hawDTmWa', 1, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(249, '2025-04-22 10:13:42', 911, 'lLi5LT4y', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(250, '2025-04-22 10:16:30', 911, 'dqHIZTvO', 1, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(251, '2025-04-22 11:10:14', 915, 'YtwKIviA', 1, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(252, '2025-04-22 11:10:14', 915, 'hfOrZOlC', 1, 'process', 917, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(253, '2025-04-22 11:10:46', 923, '8OyCfp8n', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(255, '2025-04-22 20:09:16', 723, 'Q2dx8cAL', 0, 'process', 849, NULL, 849, 723, NULL, NULL, NULL, NULL, 'black', NULL),
(256, '2025-04-22 20:53:39', 723, 'KtpQp7Ga', 0, 'process', 849, NULL, 723, 849, NULL, NULL, NULL, NULL, 'black', NULL),
(257, '2025-04-22 21:31:51', 723, 'OdvZTSmx', 0, 'end', 849, 'red', 849, 723, NULL, NULL, NULL, NULL, 'black', NULL),
(258, '2025-04-22 21:47:48', 723, 'pxwZYfQb', 0, 'process', 849, NULL, 849, 723, NULL, NULL, NULL, NULL, 'red', NULL),
(259, '2025-04-22 23:17:23', 723, 'QTaUURzC', 0, 'end', 849, 'black', 849, 723, NULL, NULL, NULL, NULL, 'red', NULL),
(260, '2025-04-23 02:33:05', 723, 'TAPMp9Rv', 0, 'process', 849, NULL, 849, 723, NULL, NULL, NULL, NULL, 'red', NULL),
(261, '2025-04-23 04:05:27', 723, '2rJcXaMq', 0, 'process', 849, NULL, 723, 849, NULL, NULL, NULL, NULL, 'red', NULL),
(262, '2025-04-24 00:52:02', 723, 'kQKNp7Bs', 0, 'process', 849, NULL, 723, 849, NULL, NULL, NULL, NULL, 'black', NULL),
(263, '2025-04-24 03:53:32', 723, 'GIt2cCsM', 0, 'process', 849, NULL, 723, 849, NULL, NULL, NULL, NULL, 'red', NULL),
(264, '2025-04-24 13:36:19', 940, 'FlZUAWD4', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(265, '2025-04-24 13:36:21', 939, 'Z0jCkynW', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(266, '2025-04-24 13:40:21', 940, 'cUv0HZue', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(267, '2025-04-24 13:40:54', 939, 'l9MIltlw', 0, 'process', 940, NULL, 940, 939, NULL, NULL, NULL, NULL, 'black', NULL),
(268, '2025-04-24 13:42:07', 939, 'zrfqGshs', 0, 'process', 940, NULL, 939, 940, NULL, NULL, NULL, NULL, 'red', NULL),
(269, '2025-04-25 03:16:27', 723, 'xZglbh9W', 0, 'end', 849, 'red', 849, 723, NULL, NULL, NULL, NULL, 'black', NULL),
(270, '2025-04-25 03:27:22', 723, '0WFrXfWD', 0, 'end', 849, 'black', 723, 849, NULL, NULL, NULL, NULL, 'red', NULL),
(271, '2025-04-25 05:31:39', 939, '71qSbbB5', 0, 'process', 940, NULL, 940, 939, NULL, NULL, NULL, NULL, 'red', NULL),
(272, '2025-04-25 05:32:34', 939, 'SUxS2zJ1', 1, 'process', 940, NULL, 940, 939, NULL, NULL, NULL, NULL, 'red', NULL),
(273, '2025-04-27 02:29:04', 723, 'KwgUImxb', 0, 'process', 849, NULL, 723, 849, NULL, NULL, NULL, NULL, 'red', NULL),
(274, '2025-04-27 16:46:41', 723, 'Uo8wRHPV', 0, 'process', 849, NULL, 723, 849, NULL, NULL, NULL, NULL, 'red', NULL),
(275, '2025-04-28 07:38:51', 950, 'Uksc1wOk', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(276, '2025-04-28 07:39:24', 951, 'F3ZijdJj', 1, 'process', 950, NULL, 950, 951, NULL, NULL, NULL, NULL, 'red', NULL),
(277, '2025-04-28 07:47:53', 953, 'EfKRbeyL', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(278, '2025-04-28 07:48:55', 954, 'pWJgYrjz', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(279, '2025-04-28 07:48:57', 953, 'AaAdjYXQ', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(280, '2025-04-28 07:50:30', 954, 'fRHYFob0', 1, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(281, '2025-04-28 07:52:15', 953, 'dQeDVlIT', 0, 'process', 955, NULL, 953, 955, NULL, NULL, NULL, NULL, 'red', NULL),
(282, '2025-04-28 07:53:58', 959, 'rHPtMBkZ', 0, 'process', 958, NULL, 959, 958, NULL, NULL, NULL, NULL, 'black', NULL),
(283, '2025-04-28 07:54:06', 960, 'JPMS7gMu', 0, 'process', 961, NULL, 961, 960, NULL, NULL, NULL, NULL, 'red', NULL),
(284, '2025-04-28 07:55:53', 962, 'Qm9HBgHd', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(285, '2025-04-28 07:55:56', 960, 'ougAwD4J', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(286, '2025-04-28 07:56:10', 963, 'HVR33kxc', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(287, '2025-04-28 07:56:33', 962, 'jcaCpaTu', 1, 'process', 960, NULL, 962, 960, NULL, NULL, NULL, NULL, 'red', NULL),
(288, '2025-04-28 07:57:05', 963, '5msC00BN', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(289, '2025-04-28 07:57:08', 964, 'Fyy5rwhe', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(290, '2025-04-28 07:58:10', 964, '3HW1SQmB', 0, 'process', 963, NULL, 963, 964, NULL, NULL, NULL, NULL, 'red', NULL),
(291, '2025-04-28 07:58:33', 959, 'WdrhDsvd', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(292, '2025-04-28 07:59:47', 966, 'bFnv9aE1', 1, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(293, '2025-04-28 08:00:34', 953, '5mEh7TGT', 0, 'end', 967, '967', 967, 953, NULL, NULL, NULL, NULL, 'black', NULL),
(294, '2025-04-28 08:02:13', 968, 'GNaxOJEE', 0, 'end', 959, '959', 959, 968, NULL, NULL, NULL, NULL, 'black', NULL),
(295, '2025-04-28 08:02:26', 959, 'i2DHANKC', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(296, '2025-04-28 08:02:46', 963, 'SiJKhFJR', 0, 'end', 964, '963', 963, 964, NULL, NULL, NULL, NULL, 'black', NULL),
(297, '2025-04-28 08:07:43', 967, 'oF0BGRKL', 0, 'process', 970, NULL, 967, 970, NULL, NULL, NULL, NULL, 'black', NULL),
(298, '2025-04-28 08:09:10', 967, 'g1d1iMrt', 1, 'process', 971, NULL, 967, 971, NULL, NULL, NULL, NULL, 'black', NULL),
(299, '2025-04-28 08:11:52', 959, 'O7t6Pbvs', 1, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(300, '2025-04-28 18:24:07', 723, 'CUf0zRJM', 0, 'process', 849, NULL, 723, 849, NULL, NULL, NULL, NULL, 'red', NULL),
(301, '2025-04-28 19:54:53', 849, 'AgLbHpQz', 0, 'process', 723, NULL, 723, 849, NULL, NULL, NULL, NULL, 'red', NULL),
(302, '2025-04-28 19:56:33', 849, 'R1QBt5a2', 0, 'process', 723, NULL, 849, 723, NULL, NULL, NULL, NULL, 'red', NULL),
(303, '2025-04-28 20:07:53', 723, 'DcD7ViW8', 0, 'process', 849, NULL, 723, 849, NULL, NULL, NULL, NULL, 'red', NULL),
(304, '2025-04-28 20:10:58', 723, 'pZ9FTOxo', 0, 'process', 849, NULL, 723, 849, NULL, NULL, NULL, NULL, 'black', NULL),
(305, '2025-04-28 20:29:26', 723, '0BVadBYJ', 0, 'process', 849, NULL, 723, 849, NULL, NULL, NULL, NULL, 'red', NULL),
(306, '2025-04-28 20:36:04', 723, 'HZBd306X', 0, 'process', 849, NULL, 849, 723, NULL, NULL, NULL, NULL, 'red', NULL),
(307, '2025-04-28 20:59:01', 723, 'Xd8jhYjG', 0, 'end', 849, 'black', 849, 723, NULL, NULL, NULL, NULL, 'red', NULL),
(308, '2025-04-28 22:44:56', 723, 'svLUrLcd', 0, 'process', 849, NULL, 849, 723, NULL, NULL, NULL, NULL, 'black', NULL),
(309, '2025-04-29 05:22:52', 973, 'yDlb3Ofl', 0, 'end', 974, '974', 974, 973, NULL, NULL, NULL, NULL, 'black', NULL),
(310, '2025-04-29 07:10:21', 977, 'QEsBZTXF', 0, 'end', 978, '978', 977, 978, NULL, NULL, NULL, NULL, 'red', NULL),
(311, '2025-04-29 07:17:44', 981, 'MYGIuEep', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(312, '2025-04-29 07:20:16', 985, 'ctfhOdY6', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(313, '2025-04-29 07:20:22', 987, '4TlkhgNh', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(314, '2025-04-29 07:20:45', 985, 'repRfN13', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(315, '2025-04-29 07:20:46', 988, '4KowBgHr', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(316, '2025-04-29 07:21:00', 987, '875bnLAv', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(317, '2025-04-29 07:21:29', 988, 'ut9g50Ok', 1, 'process', 987, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(318, '2025-04-29 07:21:43', 985, 'Lq2AatSg', 1, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(319, '2025-04-29 07:21:44', 987, 'EFO8oAjL', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(320, '2025-04-29 07:23:05', 992, 'skwjQsUT', 1, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(321, '2025-04-29 14:18:01', 1000, '4nqghKdm', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(322, '2025-04-29 14:45:46', 1000, 'B1VlHsjM', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(323, '2025-04-29 15:24:18', 938, 'MsUVZVPB', 1, 'process', 1000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(324, '2025-04-29 16:46:08', 945, '4q4SNz33', 0, 'process', 944, NULL, 944, 945, NULL, NULL, NULL, NULL, 'black', NULL),
(325, '2025-04-29 17:04:11', 945, 'MwFiRnpz', 1, 'process', 944, NULL, 945, 944, NULL, NULL, NULL, NULL, 'red', NULL),
(326, '2025-04-30 06:19:46', 999, 'gHa9o5y1', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(327, '2025-04-30 06:20:05', 941, 'Z3bfDN6U', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(328, '2025-04-30 06:21:15', 941, 'lwEP55TS', 0, 'process', 999, NULL, 941, 999, NULL, NULL, NULL, NULL, 'black', NULL),
(329, '2025-04-30 06:33:04', 258, 'eMTM5u38', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(330, '2025-04-30 06:33:36', 258, 'kjAkn3ZY', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(331, '2025-04-30 07:13:53', 942, '3rAPCVl5', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(332, '2025-04-30 07:13:53', 942, 'G2wfUmWf', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(333, '2025-04-30 07:15:06', 258, 'xPFZOfRf', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(334, '2025-04-30 07:16:04', 941, 'D50vMljh', 0, 'process', 942, NULL, 941, 942, NULL, NULL, NULL, NULL, 'black', NULL),
(335, '2025-04-30 07:39:28', 1004, 'QbWUygQ2', 1, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(336, '2025-04-30 07:40:45', 1007, 'B4FDOo8W', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(337, '2025-04-30 07:45:25', 230, 'p4Yz3lhJ', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(338, '2025-04-30 07:47:08', 941, 'JxExrpVj', 0, 'process', 942, NULL, 942, 941, NULL, NULL, NULL, NULL, 'black', NULL),
(339, '2025-04-30 07:50:22', 942, 'LVbkXLEt', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(340, '2025-04-30 07:50:22', 942, 'Z0PJRB33', 0, 'process', 941, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(341, '2025-04-30 07:53:42', 1007, '4liwyHcx', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(342, '2025-04-30 07:55:29', 1008, 'S9CLqByo', 0, 'end', 942, '1008', 942, 1008, NULL, NULL, NULL, NULL, 'red', NULL),
(343, '2025-04-30 07:58:18', 230, 'DYM6eP0P', 1, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(344, '2025-04-30 08:08:53', 1007, 's5fB3Gxo', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(345, '2025-04-30 08:11:01', 973, '4k2WADnL', 1, 'process', 975, NULL, 975, 973, NULL, NULL, NULL, NULL, 'black', NULL),
(346, '2025-04-30 14:12:08', 1016, '3krb46Uq', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(347, '2025-04-30 14:13:00', 1016, 'OTPvguqM', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(348, '2025-04-30 14:35:25', 258, 'OIPCk6C7', 1, 'process', 723, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(349, '2025-04-30 16:10:04', 1016, 'XK3kPkGp', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(350, '2025-04-30 16:59:06', 996, 'JcKwym3s', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(351, '2025-04-30 16:59:39', 996, 'XKtRn6qd', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(352, '2025-04-30 17:00:32', 996, 'kT4dMUVD', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(353, '2025-04-30 17:59:04', 1007, '9Q23zaHW', 0, 'process', 1016, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(354, '2025-05-01 00:03:54', 1018, '5xHngZFh', 0, 'process', 849, NULL, 849, 1018, NULL, NULL, NULL, NULL, 'red', NULL),
(355, '2025-05-01 19:08:01', 1018, 'MoBIVt1h', 0, 'process', 849, NULL, 1018, 849, NULL, NULL, NULL, NULL, 'red', NULL),
(356, '2025-05-02 23:43:46', 1018, 'bAxnDQZS', 0, 'process', 849, NULL, 849, 1018, NULL, NULL, NULL, NULL, 'black', NULL),
(357, '2025-05-03 18:13:30', 1016, '0ztsCxUV', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(358, '2025-05-03 18:16:27', 1016, 'eYlDRc19', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(359, '2025-05-03 18:34:12', 849, 'G4Sb2vC2', 0, 'process', 1018, NULL, 1018, 849, NULL, NULL, NULL, NULL, 'black', NULL),
(360, '2025-05-04 14:15:04', 1008, 'B6hygbDG', 0, 'end', 942, '942', 1008, 942, NULL, NULL, NULL, NULL, 'red', NULL),
(361, '2025-05-04 14:21:07', 1016, '1H3fhpMo', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(362, '2025-05-04 14:40:17', 1016, 'ngyw7pRt', 0, 'process', 1008, NULL, 1016, 1008, NULL, NULL, NULL, NULL, 'black', NULL),
(363, '2025-05-05 05:20:44', 1021, 'O2CO68BX', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(364, '2025-05-05 05:21:26', 1021, '55qkr8oF', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(365, '2025-05-05 05:22:19', 1021, 'tSCpGnXK', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(366, '2025-05-05 05:24:16', 1021, 'poGjOEqX', 1, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL),
(367, '2025-05-05 08:01:30', 1008, 'Ngg4qcDR', 0, 'end', 942, '1008', 942, 1008, NULL, NULL, NULL, NULL, 'red', NULL),
(368, '2025-05-06 00:42:55', 849, '3B83y6UB', 0, 'process', 1018, NULL, 1018, 849, NULL, NULL, NULL, NULL, 'black', NULL),
(369, '2025-05-06 05:06:48', 849, 'ZD7kYoLG', 0, 'process', 1018, NULL, 1018, 849, NULL, NULL, NULL, NULL, 'red', NULL),
(370, '2025-05-06 23:45:00', 1023, 'pFnJMrSx', 0, 'prepare', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'red', NULL);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `sh_party`
--
ALTER TABLE `sh_party`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `sh_party`
--
ALTER TABLE `sh_party`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=371;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
